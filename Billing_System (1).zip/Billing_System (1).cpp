#include <iostream>
using namespace std;
int purchase=0;
void ask();
void display();
struct Customer{
     string items;
     int quantity;
     int amount;
}c[45];

int snacks()
{
    int op;
   cout<<"1.Biscuits\n2.Chocolates\n3.Chips\n";
   cin>>op;
    switch(op)
    {
    case 1:
        int opp;
        cout<<"Choose it\n1.Dark Fantasy-30\n2.Parle-G-5\n3.Malkist-10\n";
        cin>>opp;
        switch(opp)
        {
        case 1:
            {
            c[1].items="Dark Fantasy";
            int countt;
            int df=30;
            cout<<"Enter the count:\n";
            cin>>countt;
            c[1].quantity=countt;
            countt=countt*df;
            c[1].amount=countt;
            purchase+=countt;
            ask();
            break;
            }
        case 2:
            {
            c[2].items="Parle-G     ";
            int G;
            int pg=5;
            cout<<"Enter the count:\n";
            cin>>G;
            c[2].quantity=G;
            G=G*pg;
            c[2].amount=G;
            purchase+=G;
            ask();
            break;
            }

            case 3:
            {
            c[3].items="Milkist";
            int cc;
            int Mt=10;
            cout<<"Enter the count:\n";
            cin>>cc;
            c[3].quantity=cc;
            cc=cc*Mt;
            c[3].amount=cc;
            purchase+=cc;
            ask();
            break;
            }

        }
    }


switch(op)
{
    case 2:
     int chl;
     cout<<"Choose it\n1.KitKat-10\n2.milkybar-20\n3.Dairymik-50\n";
     cin>>chl;
switch (chl)
{
  case 1:
      {
        c[4].items="KitKat";
        int A;
        int kt=10;
        cout<<"Enter your count:\n";
        cin>>A;
        c[4].quantity=A;
        A=A*kt;
        c[4].amount=A;
        purchase+=A;
        ask();
        break;

      }
  case 2:
    {
      c[5].items="Milkybar";
      int B;
      int mr=20;
      cout<<"Enter your count:\n";
      cin>>B;
      c[5].quantity=B;
      B=B*mr;
      c[5].amount=B;
      purchase+=B;
      ask();
      break;

    }
  case 3:
    {
     c[6].items="Dairymilk";
     int C;
     int dk=50;
     cout<<"Enter your count:\n";
     cin>>C;
     c[6].quantity=C;
     C=C*dk;
     c[6].amount=C;
     purchase+=C;
     ask();
     break;
    }
}
}
switch(op)
{
    case 3:
     int cps;
     cout<<"Choose it\n1.Bingo-5\n2.Lays-10\n3.Pringles-20\n";
     cin>>cps;
switch (cps)
{
  case 1:
      {
        c[7].items="Bingo";
        int B;
        int Bo=5;
        cout<<"Enter your count:\n";
        cin>>B;
        c[7].quantity=B;
        B=B*Bo;
        c[7].amount=B;
        purchase+=B;
        ask();
        break;

      }
  case 2:
    {
      c[8].items="Lays";
      int L;
      int Ls=10;
      cout<<"Enter your count:\n";
      cin>>L;
      c[8].quantity=L;
      L=L*Ls;
      c[8].amount=L;
      purchase+=L;
      ask();
      break;

    }
  case 3:
    {
     c[9].items="Pringles";
     int P;
     int Ps=30;
     cout<<"Enter your count:\n";
     cin>>P;
     c[9].quantity=P;
     P=P*Ps;
     c[9].amount=P;
     purchase+=P;
     ask();
     break;
    }


}

    }
}
int stationery()
{
    int sty;
   cout<<"1.pens\n2.pencils\n3.notes\n";
   cin>>sty;
    switch(sty)
    {
    case 1:
        int pn;
        cout<<"Choose it\n1.Heropen-50\n2.flairpen-25\n3.stickpen-10\n";
        cin>>pn;
        switch(pn)
        {
        case 1:
            {
            c[10].items="Heropen";
            int H;
            int hn=50;
            cout<<"Enter the count:\n";
            cin>>H;
            c[10].quantity=H;
            H=H*hn;
            c[10].amount=H;
            purchase+=H;
            ask();
            break;
            }
        case 2:
            {
            c[11].items="flairpen";
            int F;
            int fr=25;
            cout<<"Enter the count:\n";
            cin>>F;
            c[11].quantity=F;
            F=F*fr;
            c[11].amount=F;
            purchase+=F;
            ask();
            break;
            }

            case 3:
            {
            c[12].items="stickpen";
            int S;
            int sk=10;
            cout<<"Enter the count:\n";
            cin>>S;
            c[12].quantity=S;
            S=S*sk;
            c[12].amount=S;
            purchase+=sk;
            ask();
            break;
            }

        }
    }
    switch(sty)
{
    case 2:
     int pel;
     cout<<"Choose it\n1.HPpencil-10\n2.Doms-5\n3.Flora-6\n";
     cin>>pel;
switch (pel)
{
  case 1:
      {
        c[13].items="HPpencil";
        int HP;
        int pl=10;
        cout<<"Enter your count:\n";
        cin>>HP;
        c[13].quantity=HP;
        HP=HP*pl;
        c[13].amount=HP;
        purchase+=HP;
        ask();
        break;

      }
  case 2:
    {
      c[14].items="Doms";
      int D;
      int ds=5;
      cout<<"Enter your count:\n";
      cin>>D;
      c[14].quantity=D;
      D=D*ds;
      c[14].amount=D;
      purchase+=D;
      ask();
      break;

    }
  case 3:
    {
     c[15].items="Flora";
     int F;
     int fa=6;
     cout<<"Enter your count:\n";
     cin>>F;
     c[15].quantity=F;
     F=F*fa;
     c[15].amount=F;
     purchase+=F;
     ask();
     break;
    }
}
}
switch(sty)
{
    case 3:
     int Nts;
     cout<<"Choose it\n1.Rulednote-30\n2.Unrulednote-30\n3.Graphnote-20\n";
     cin>>Nts;
switch (Nts)
{
  case 1:
      {
        c[16].items="Rulednote";
        int R;
        int re=30;
        cout<<"Enter your count:\n";
        cin>>R;
        c[16].quantity=R;
        R=R*re;
        c[16].amount=R;
        purchase+=R;
        ask();
        break;

      }
  case 2:
    {
      c[17].items="Unrulednote";
      int U;
      int un=30;
      cout<<"Enter your count:\n";
      cin>>U;
      c[17].quantity=U;
      U=U*un;
      c[17].amount=U;
      purchase+=U;
      ask();
      break;

    }
  case 3:
    {
    c[18].items="Graphnote";
     int G;
     int gh=20;
     cout<<"Enter your count:\n";
     cin>>G;
     c[18].quantity=G;
     G=G*gh;
     c[18].amount=G;
     purchase+=G;
     ask();
     break;
    }


}

    }


}
int Cosmetics()
{
    int Cms;
   cout<<"1.facepowders\n2.perfumes\n3.lipsticks\n";
   cin>>Cms;
    switch(Cms)
    {
    case 1:
        int FP;
        cout<<"Choose it\n1.Nivea-100\n2.Yardley-150\n3.WhiteTone-200\n";
        cin>>FP;
        switch(FP)
        {
        case 1:
            {
            c[19].items="Nivea";
            int N;
            int na=100;
            cout<<"Enter the count:\n";
            cin>>N;
            c[19].quantity=N;
            N=N*na;
            c[19].amount=N;
            purchase+=N;
            ask();
            break;
            }
        case 2:
            {
            c[20].items="Yardley";
            int Y;
            int yl=150;
            cout<<"Enter the count:\n";
            cin>>Y;
            c[20].quantity=Y;
            Y=Y*yl;
            c[20].amount=Y;
            purchase+=Y;
            ask();
            break;
            }

            case 3:
            {
            c[21].items="Whitetone";
            int W;
            int wt=200;
            cout<<"Enter the count:\n";
            cin>>W;
            c[21].quantity=W;
            W=W*wt;
            c[21].amount=W;
            purchase+=W;
            ask();
            break;
            }

        }
    }


switch(Cms)
{
    case 2:
     int pfe;
     cout<<"Choose it\n1.Eva-150\n2.Jasmine-220\n3.sandalwood-250\n";
     cin>>pfe;
switch (pfe)
{
  case 1:
      {
        c[22].items="Eva";
        int E;
        int ea=150;
        cout<<"Enter your count:\n";
        cin>>E;
        c[22].quantity=E;
        E=E*ea;
        c[22].amount=E;
        purchase+=E;
        ask();
        break;

      }
  case 2:
    {
      c[23].items="Jasmine";
      int J;
      int je=220;
      cout<<"Enter your count:\n";
      cin>>J;
      c[23].quantity=J;
      J=J*je;
      c[23].amount=J;
      purchase+=J;
      ask();
      break;

    }
  case 3:
    {
     c[24].items="Sandalwood";
     int S;
     int sd=250;
     cout<<"Enter your count:\n";
     cin>>S;
     c[24].quantity=S;
     S=S*sd;
     c[24].amount=S;
     purchase+=S;
     ask();
     break;
    }
}
}
switch(Cms)
{
    case 3:
     int lps;
     cout<<"Choose it\n1.Mattelipstrick-150\n2.Liquidlipsticks-300\n3.Waterproof-450\n";
     cin>>lps;
switch (lps)
{
  case 1:
      {
        c[25].items="Mattelipstrick";
        int M;
        int me=150;
        cout<<"Enter your count:\n";
        cin>>M;
        c[25].quantity=M;
        M=M*me;
        c[25].amount=M;
        purchase+=M;
        ask();
        break;

      }
  case 2:
    {
      c[26].items="Liquidlipsticks";
      int L;
      int ld=300;
      cout<<"Enter your count:\n";
      cin>>L;
      c[26].quantity=L;
      L=L*ld;
      c[26].amount=L;
      purchase+=L;
      ask();
      break;

    }
  case 3:
    {
     c[27].items="Waterproof";
     int W;
     int wp=450;
     cout<<"Enter your count:\n";
     cin>>W;
     c[27].quantity=W;
     W=W*wp;
     c[27].amount=W;
     purchase+=W;
     ask();
     break;
    }


}

    }
}

int Groceries()
{
    int grs;
   cout<<"1.Fruits\n2.Vegetables\n3.Dairys\n";
   cin>>grs;
    switch(grs)
    {
    case 1:
        int Ft;
        cout<<"Choose it\n1.Apple(1kg)-200\n2.Watermelon(1kg)-30\n3.Orange(1kg)-150\n";
        cin>>Ft;
        switch(Ft)
        {
        case 1:
            {
            c[28].items="Apple";
            int A;
            int ae=200;
            cout<<"Enter the count:\n";
            cin>>A;
            c[28].quantity=A;
            A=A*ae;
            c[28].amount=A;
            purchase+=A;
            ask();
            break;
            }
        case 2:
            {
            c[29].items="Watermelon";
            int W;
            int wn=30;
            cout<<"Enter the count:\n";
            cin>>W;
            c[29].quantity=W;
            W=W*wn;
            c[29].amount=W;
            purchase+=W;
            ask();
            break;
            }

            case 3:
            {
            c[30].items="Orange";
            int O;
            int oe=150;
            cout<<"Enter the count:\n";
            cin>>O;
            c[30].quantity=O;
            O=O*oe;
            c[30].amount=O;
            purchase+=oe;
            ask();
            break;
            }

        }
    }
    switch(grs)
{
    case 2:
     int veg;
     cout<<"Choose it\n1.Tomato(1kg)-30\n2.Onion(1kg)-25\n3.Potato(1kg)-15\n";
     cin>>veg;
switch (veg)
{
  case 1:
      {
        c[31].items="Tomato";
        int T;
        int to=30;
        cout<<"Enter your count:\n";
        cin>>T;
        c[31].quantity=T;
        T=T*to;
        c[31].amount=T;
        purchase+=T;
        ask();
        break;

      }
  case 2:
    {
      c[32].items="Onion";
      int O;
      int on=25;
      cout<<"Enter your count:\n";
      cin>>O;
      c[32].quantity=O;
      O=O*on;
      c[32].amount=O;
      purchase+=O;
      ask();
      break;

    }
  case 3:
    {
     c[33].items="Potato";
     int P;
     int po=15;
     cout<<"Enter your count:\n";
     cin>>P;
     c[33].quantity=P;
     P=P*po;
     c[33].amount=P;
     purchase+=P;
     ask();
     break;
    }
}
}
switch(grs)
{
    case 3:
     int drs;
     cout<<"Choose it\n1.Milk-50\n2.Eggs-6\n3.Curd-40\n";
     cin>>drs;
switch (drs)
{
  case 1:
      {
        c[34].items="Milk";
        int M;
        int mk=50;
        cout<<"Enter your count:\n";
        cin>>M;
        c[34].quantity=M;
        M=M*mk;
        c[34].amount=M;
        purchase+=M;
        ask();
        break;

      }
  case 2:
    {
      c[35].items="Eggs";
      int E;
      int es=6;
      cout<<"Enter your count:\n";
      cin>>E;
      c[35].quantity=E;
      E=E*es;
      c[35].amount=E;
      purchase+=E;
      ask();
      break;

    }
  case 3:
    {
     c[36].items="Curd";
     int C;
     int cd=40;
     cout<<"Enter your count:\n";
     cin>>C;
     c[36].quantity=C;
     C=C*cd;
     c[36].amount=C;
     purchase+=C;
     ask();
     break;
    }


}

    }


}
int Others()
{
    int Ors;
   cout<<"1.Sauces\n2.Spices\n3.Dried\n";
   cin>>Ors;
    switch(Ors)
    {
    case 1:
        int Sus;
        cout<<"Choose it\n1.Tomatosauce-200\n2.Soyasauce-250\n3.Mayonnaise-300\n";
        cin>>Sus;
        switch(Sus)
        {
        case 1:
            {
            c[37].items="Tomatosauce";
            int T;
            int te=200;
            cout<<"Enter the count:\n";
            cin>>T;
            c[37].quantity=T;
            T=T*te;
            c[37].amount=T;
            purchase+=T;
            ask();
            break;
            }
        case 2:
            {
            c[38].items="soyasauce";
            int S;
            int sa=250;
            cout<<"Enter the count:\n";
            cin>>S;
            c[38].quantity=S;
            S=S*sa;
            c[38].amount=S;
            purchase+=S;
            ask();
            break;
            }

            case 3:
            {
            c[39].items="Mayonnaise";
            int M;
            int me=300;
            cout<<"Enter the count:\n";
            cin>>M;
            c[39].quantity=M;
            M=M*me;
            c[39].amount=M;
            purchase+=M;
            ask();
            break;
            }

        }
    }
    switch(Ors)
{
    case 2:
     int sps;
     cout<<"Choose it\n1.Chillipowder(1kg)-300\n2.Turmericpowder(1kg)-150\n3.Cuminpowder(1kg)-250\n";
     cin>>sps;
switch (sps)
{
  case 1:
      {
        c[40].items="chillipowder";
        int C;
        int cr=300;
        cout<<"Enter your count:\n";
        cin>>C;
        c[40].quantity=C;
        C=C*cr;
        c[40].amount=C;
        purchase+=C;
        ask();
        break;

      }
  case 2:
    {
      c[41].items="Turmericpowder";
      int T;
      int tr=150;
      cout<<"Enter your count:\n";
      cin>>T;
      c[41].quantity=T;
      T=T*tr;
      c[41].amount=T;
      purchase+=T;
      ask();
      break;

    }
  case 3:
    {
     c[42].items="Cuminpowder";
     int C;
     int cn=250;
     cout<<"Enter your count:\n";
     cin>>C;
     c[42].quantity=C;
     C=C*cn;
     c[42].amount=C;
     purchase+=C;
     ask();
     break;
    }
}
}
switch(Ors)
{
    case 3:
     int drd;
     cout<<"Choose it\n1.Dates(1kg)-250\n2.Almond(1kg)-200\n3.Walnut(1kg)-300\n";
     cin>>drd;
switch (drd)
{
  case 1:
      {
        c[43].items="Dates";
        int D;
        int ds=250;
        cout<<"Enter your count:\n";
        cin>>D;
        c[43].quantity=D;
        D=D*ds;
        c[43].amount=D;
        purchase+=D;
        ask();
        break;

      }
  case 2:
    {
     c[44].items="Almond";
      int A;
      int ad=200;
      cout<<"Enter your count:\n";
      cin>>A;
      c[44].quantity=A;
      A=A*ad;
      c[44].amount=A;
      purchase+=A;
      ask();
      break;

    }
  case 3:
    {
     c[45].items="Walnut";
     int W;
     int wt=300;
     cout<<"Enter your count:\n";
     cin>>W;
     c[45].quantity=W;
     W=W*wt;
     c[45].amount=W;
     purchase+=W;
     ask();
     break;
    }


}

    }


}


void ask()
{
    int op;
    cout<<"Do you want to continue?\n1.Yes\n2.No\n";
    cin>>op;
    switch(op)
    {
    case 1:
        display();
        break;

    case 2:
        cout<<"THanking You\n";
        break;
    }


}


void display()
{
    int op;

    cout<<"\n\t\t\tMy Divisions are..:\n\n";
    cout<<"\t\t\t\t1.Snacks\n\t\t\t\t2.Stationery\n\t\t\t\t3.Cosmetics\n\t\t\t\t4.Groceries\n\t\t\t\t5.Others\n";
    cout<<"Select your option:\n";
    cin>>op;

    switch(op)
    {
    case 1:
        snacks();
        break;
    case 2:
        stationery();
        break;
    case 3:
        Cosmetics();
        break;
    case 4:
        Groceries();
        break;
    case 5:
        Others();
        break;

    }


}
int main()
{
    cout<<"\t\t\t\t==============================="<<endl;
    cout<<"\t\t\t\tWelcome to our Department Store"<<endl;
    cout<<"\t\t\t\t==============================="<<endl;
    display();
cout<<"   items\t\tquantity\t\tamount\n";
for(int i=1;i<=45;i++){
    cout<<c[i].items<<"\t\t  ";
    cout<<c[i].quantity<<"\t\t  ";
    cout<<c[i].amount<<"\t\t\n";
}

cout<<"TOtal Purchasing amount:"<<purchase<<endl;
}
